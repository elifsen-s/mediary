const { Pool } = require('pg');

const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'mediary_db',
    password: process.env.DB_PASSWORD || '1234',
    port: process.env.DB_PORT || 5432,
});

async function initDb() {
    try {
        await pool.query('SELECT NOW()');
        console.log('>>> DATABASE CONNECTED (mediary_db) <<<');
        await pool.query(`
            DO $$ BEGIN 
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='content' AND column_name='description') THEN ALTER TABLE content ADD COLUMN description TEXT; END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='content' AND column_name='avg_score') THEN ALTER TABLE content ADD COLUMN avg_score NUMERIC(4,2) DEFAULT 0.00; END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='pp_url') THEN ALTER TABLE users ADD COLUMN pp_url TEXT; END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='first_name') THEN ALTER TABLE users ADD COLUMN first_name VARCHAR(50); END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='last_name') THEN ALTER TABLE users ADD COLUMN last_name VARCHAR(50); END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='content_likes' AND column_name='like_date') THEN ALTER TABLE content_likes ADD COLUMN like_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP; END IF;
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='post_likes' AND column_name='like_date') THEN ALTER TABLE post_likes ADD COLUMN like_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP; END IF;
            END $$;
        `);
    } catch (err) {
        console.error('!!! DATABASE INITIALIZATION ERROR !!!', err.message);
    }
}

module.exports = { pool, initDb };
