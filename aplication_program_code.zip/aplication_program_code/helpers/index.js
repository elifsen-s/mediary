const { pool } = require('../db/pool');

/**
 * Returns the user by their ID.
 */
async function getUser(id) {
    if (!id) return null;
    try {
        const res = await pool.query(
            "SELECT *, user_name as username, TRIM(CONCAT(first_name, ' ', middle_name, ' ', last_name)) as full_name FROM users WHERE user_id = $1",
            [parseInt(id)]
        );
        return res.rows[0];
    } catch (e) {
        return null;
    }
}

/**
 * Saves the genres for a given content item to the database.
 * type: 'Movie' | 'Series' | 'Book'
 */
async function saveGenres(dbContentId, apiData, type) {
    const knownGenres = [
        "Action", "Adventure", "Spy", "Martial Arts", "Military", "Western", "Survival",
        "Fantasy", "Sci-Fi", "Horror", "Dystopian", "Paranormal",
        "Detective", "Crime", "Mystery", "Thriller", "Noir", "Legal",
        "Drama", "Romance", "Family", "Young Adult", "Children", "Bildungsroman",
        "Comedy", "Black Comedy", "Satire", "Sitcom", "Parody",
        "Biography", "History", "Philosophy", "Psychology", "Religion", "Sociology", "Politics",
        "Science", "Mathematics", "Medicine", "Technology", "Environment",
        "Art", "Music", "Photography", "Cooking", "Travel", "Sports", "Self-Help", "Business",
        "Animation", "Documentary", "Short Film", "Reality-TV", "Talk-Show", "Competition", "News", "Musical",
        "Comics", "Poetry", "Essay", "Antology", "Reference", "Play", "Epistolary",
        "Experimental", "Folklore", "Fable"
    ];

    let rawGenres = [];
    if (type === 'Movie' || type === 'Series') {
        if (apiData.genres) rawGenres = apiData.genres.map(g => g.name);
    } else if (type === 'Book') {
        if (apiData.subjects) rawGenres = apiData.subjects.slice(0, 5);
    }

    const targetGenreNames = new Set();
    for (let raw of rawGenres) {
        let genreName = raw.trim();
        
        // Find best match in known genres
        let matched = knownGenres.find(k => k.toLowerCase() === genreName.toLowerCase());
        
        // Specific manual mappings for common API differences
        if (!matched) {
            if (genreName.toLowerCase().includes('science fiction')) matched = "Sci-Fi";
            else if (genreName.toLowerCase().includes('action & adventure')) {
                targetGenreNames.add("Action");
                targetGenreNames.add("Adventure");
                continue;
            }
            else if (genreName.toLowerCase().includes('sci-fi & fantasy')) {
                targetGenreNames.add("Sci-Fi");
                targetGenreNames.add("Fantasy");
                continue;
            }
        }

        // If still not matched, use a clean version of the name
        if (!matched) {
            matched = genreName.charAt(0).toUpperCase() + genreName.slice(1).toLowerCase();
        }
        
        targetGenreNames.add(matched);
    }

    for (const genreName of targetGenreNames) {
        const gCheck = await pool.query("SELECT genre_id FROM genre WHERE genre_name = $1", [genreName]);
        const gid = gCheck.rows.length > 0
            ? gCheck.rows[0].genre_id
            : (await pool.query("INSERT INTO genre (genre_name) VALUES ($1) RETURNING genre_id", [genreName])).rows[0].genre_id;
        
        await pool.query("INSERT INTO belong_to (b_content_id, b_genre_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", [dbContentId, gid]);
    }
}

module.exports = { getUser, saveGenres };
