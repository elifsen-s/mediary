const express = require('express');
const router = express.Router();
const axios = require('axios');
const { pool } = require('../db/pool');
const { saveGenres } = require('../helpers');

const TMDB_API_KEY = '4c7c86f2b01916dd378c1ea2a2d50953';

function requireAuth(getCurrentUserId) {
    return (req, res, next) => {
        if (!getCurrentUserId()) {
            if (req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'))) {
                return res.status(401).json({ success: false, error: 'Not authenticated' });
            }
            return res.redirect('/?auth=login');
        }
        next();
    };
}

module.exports = function(getCurrentUserId) {
    const auth = requireAuth(getCurrentUserId);

    // İÇERİK DETAY
    router.get('/content/:id', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            let contentId = req.params.id;
            let dbContentId = null;
            let tmdbData = null;
            let olData = null;

            if (contentId.toString().startsWith('tmdb_')) {
                const tmdbId = contentId.replace('tmdb_', '').replace('tv_', '');
                const tmdbType = contentId.includes('_tv_') ? 'tv' : 'movie';
                let tmdbRes = await axios.get(`https://api.themoviedb.org/3/${tmdbType}/${tmdbId}?api_key=${TMDB_API_KEY}&language=en-US&append_to_response=credits`);
                tmdbData = tmdbRes.data;
                const title = tmdbData.title || tmdbData.name;
                const existingCheck = await pool.query("SELECT content_id FROM content WHERE title = $1", [title]);
                if (existingCheck.rows.length > 0) {
                    dbContentId = existingCheck.rows[0].content_id;
                } else {
                    const typeName = tmdbType === 'movie' ? 'Movie' : 'Series';
                    let typeResult = await pool.query("SELECT type_id FROM content_type WHERE type_name ILIKE $1", [typeName]);
                    let typeId = typeResult.rows.length > 0 ? typeResult.rows[0].type_id : (await pool.query("INSERT INTO content_type (type_name) VALUES ($1) RETURNING type_id", [typeName])).rows[0].type_id;
                    const releaseYear = (tmdbData.release_date || tmdbData.first_air_date)?.substring(0, 4);
                    const insertResult = await pool.query(`INSERT INTO content (title, release_year, poster_url, c_type_id, description) VALUES ($1, $2, $3, $4, $5) RETURNING content_id`, [title, parseInt(releaseYear) || null, 'https://image.tmdb.org/t/p/w500' + tmdbData.poster_path, typeId, tmdbData.overview || '']);
                    dbContentId = insertResult.rows[0].content_id;
                }
                await saveGenres(dbContentId, tmdbData, tmdbType === 'movie' ? 'Movie' : 'Series');

            } else if (contentId.toString().startsWith('ol_')) {
                const olId = contentId.replace('ol_', '');
                const olRes = await axios.get(`https://openlibrary.org/works/${olId}.json`);
                olData = olRes.data;
                const existingCheck = await pool.query("SELECT content_id FROM content WHERE title = $1", [olData.title]);
                if (existingCheck.rows.length > 0) {
                    dbContentId = existingCheck.rows[0].content_id;
                } else {
                    let typeId = (await pool.query("SELECT type_id FROM content_type WHERE type_name = 'Book'")).rows[0]?.type_id || (await pool.query("INSERT INTO content_type (type_name) VALUES ('Book') RETURNING type_id")).rows[0].type_id;
                    const insertResult = await pool.query(`INSERT INTO content (title, release_year, poster_url, c_type_id, description) VALUES ($1, $2, $3, $4, $5) RETURNING content_id`, [olData.title, olData.first_publish_date ? parseInt(olData.first_publish_date.toString().substring(0, 4)) : null, olData.covers ? `https://covers.openlibrary.org/b/id/${olData.covers[0]}-M.jpg` : null, typeId, olData.description?.value || olData.description || '']);
                    dbContentId = insertResult.rows[0].content_id;
                }
                await saveGenres(dbContentId, olData, 'Book');
            } else {
                dbContentId = parseInt(contentId);
            }

            if (!dbContentId || isNaN(dbContentId)) {
                return res.status(400).send("Invalid content ID.");
            }

            const contentResult = await pool.query(`
                SELECT c.*, ct.type_name as type, 
                (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                (SELECT COUNT(*) FROM content_likes WHERE c_content_id = c.content_id AND c_user_id = $2) > 0 as is_liked, 
                (SELECT score FROM rates WHERE r_content_id = c.content_id AND r_user_id = $2) as user_score 
                FROM content c JOIN content_type ct ON c.c_type_id = ct.type_id WHERE c.content_id = $1`, [dbContentId, parseInt(CURRENT_USER_ID) || 0]);
            const content = contentResult.rows[0];

            if (!content) return res.status(404).send("Content not found.");

            // API'den oyuncu/yönetmen ekle
            if (contentId.toString().startsWith('tmdb_')) {
                const tmdbId = contentId.replace('tmdb_', '').replace('tv_', '');
                const tmdbType = contentId.includes('_tv_') ? 'tv' : 'movie';
                const tmdbRes = await axios.get(`https://api.themoviedb.org/3/${tmdbType}/${tmdbId}?api_key=${TMDB_API_KEY}&language=en-US&append_to_response=credits`);
                const tmdbData = tmdbRes.data;

                let personId = null;
                if (tmdbType === 'movie' && tmdbData.credits && tmdbData.credits.crew) {
                    const dir = tmdbData.credits.crew.find(c => c.job === 'Director');
                    if (dir) {
                        await pool.query("INSERT INTO person (person_name) VALUES ($1) ON CONFLICT (person_name) DO NOTHING", [dir.name]);
                        const pRes = await pool.query("SELECT person_id FROM person WHERE person_name = $1", [dir.name]);
                        personId = pRes.rows[0].person_id;
                        await pool.query("INSERT INTO movies (m_content_id, duration, m_person_id) VALUES ($1, $2, $3) ON CONFLICT (m_content_id) DO NOTHING", [dbContentId, tmdbData.runtime || 0, personId]);
                        content.director = dir.name;
                    }
                } else if (tmdbType === 'tv' && tmdbData.created_by && tmdbData.created_by.length > 0) {
                    const creator = tmdbData.created_by[0];
                    await pool.query("INSERT INTO person (person_name) VALUES ($1) ON CONFLICT (person_name) DO NOTHING", [creator.name]);
                    const pRes = await pool.query("SELECT person_id FROM person WHERE person_name = $1", [creator.name]);
                    personId = pRes.rows[0].person_id;
                    await pool.query("INSERT INTO series (s_content_id, season_count, episode_count, s_person_id) VALUES ($1, $2, $3, $4) ON CONFLICT (s_content_id) DO NOTHING", [dbContentId, tmdbData.number_of_seasons || 0, tmdbData.number_of_episodes || 0, personId]);
                    content.creator = tmdbData.created_by.map(c => c.name).join(', ');
                }

                if (tmdbData.credits && tmdbData.credits.cast) {
                    content.cast = [];
                    for (const actor of tmdbData.credits.cast.slice(0, 10)) {
                        await pool.query("INSERT INTO person (person_name) VALUES ($1) ON CONFLICT (person_name) DO NOTHING", [actor.name]);
                        const pRes = await pool.query("SELECT person_id FROM person WHERE person_name = $1", [actor.name]);
                        const aPersonId = pRes.rows[0].person_id;
                        if (tmdbType === 'movie') {
                            await pool.query("INSERT INTO act_in_movie (a_content_id, a_person_id, m_role_name) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING", [dbContentId, aPersonId, actor.character]);
                        } else {
                            await pool.query("INSERT INTO act_in_series (as_content_id, as_person_id, s_role_name) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING", [dbContentId, aPersonId, actor.character]);
                        }
                        content.cast.push({ person_name: actor.name, role: actor.character });
                    }
                }
            } else if (contentId.toString().startsWith('ol_')) {
                const olId = contentId.replace('ol_', '');
                const olRes = await axios.get(`https://openlibrary.org/works/${olId}.json`);
                const olData = olRes.data;
                if (olData.authors && olData.authors.length > 0) {
                    const authRes = await axios.get(`https://openlibrary.org${olData.authors[0].author.key}.json`);
                    const authorName = authRes.data.name;
                    await pool.query("INSERT INTO person (person_name) VALUES ($1) ON CONFLICT (person_name) DO NOTHING", [authorName]);
                    const pRes = await pool.query("SELECT person_id FROM person WHERE person_name = $1", [authorName]);
                    const personId = pRes.rows[0].person_id;
                    await pool.query("INSERT INTO books (b_content_id, page_count, b_person_id) VALUES ($1, $2, $3) ON CONFLICT (b_content_id) DO NOTHING", [dbContentId, olData.covers ? olData.covers.length * 100 : 0, personId]);
                    content.author = authorName;
                }
            }

            // DB'den eksik bilgileri tamamla
            if (!content.director && !content.creator && !content.author) {
                if (content.type === 'Movie') {
                    const movRes = await pool.query("SELECT p.person_name FROM movies m JOIN person p ON m.m_person_id = p.person_id WHERE m.m_content_id = $1", [dbContentId]);
                    if (movRes.rows.length > 0) content.director = movRes.rows[0].person_name;
                } else if (content.type === 'Series') {
                    const serRes = await pool.query("SELECT p.person_name FROM series s JOIN person p ON s.s_person_id = p.person_id WHERE s.s_content_id = $1", [dbContentId]);
                    if (serRes.rows.length > 0) content.creator = serRes.rows[0].person_name;
                } else if (content.type === 'Book') {
                    const bookRes = await pool.query("SELECT p.person_name FROM books b JOIN person p ON b.b_person_id = p.person_id WHERE b.b_content_id = $1", [dbContentId]);
                    if (bookRes.rows.length > 0) content.author = bookRes.rows[0].person_name;
                }
            }

            if (!content.cast || content.cast.length === 0) {
                if (content.type === 'Movie' || content.type === 'Series') {
                    const castQuery = content.type === 'Movie'
                        ? "SELECT p.person_name, a.m_role_name as role FROM act_in_movie a JOIN person p ON a.a_person_id = p.person_id WHERE a.a_content_id = $1"
                        : "SELECT p.person_name, a.s_role_name as role FROM act_in_series a JOIN person p ON a.as_person_id = p.person_id WHERE a.as_content_id = $1";
                    const castRes = await pool.query(castQuery, [dbContentId]);
                    content.cast = castRes.rows;
                }
            }

            const postsRes = await pool.query(`
                SELECT p.*, u.user_name as username, 
                TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, u.pp_url, 
                (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, 
                EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $2) as is_liked 
                FROM post p JOIN users u ON p.p_user_id = u.user_id 
                WHERE p.p_content_id = $1 
                ORDER BY like_count DESC 
                LIMIT 10`, [dbContentId, parseInt(CURRENT_USER_ID) || 0]);
            res.render('content-detail', { content, posts: postsRes.rows });
        } catch (err) {
            console.error(err);
            res.status(500).send("Detail page error.");
        }
    });

    // PUAN VER
    router.post('/content/:id/rate', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const newScore = parseInt(req.body.score);
        try {
            const existing = await pool.query('SELECT score FROM rates WHERE r_user_id = $1 AND r_content_id = $2', [parseInt(CURRENT_USER_ID), req.params.id]);
            if (existing.rows.length > 0 && existing.rows[0].score === newScore) {
                await pool.query('DELETE FROM rates WHERE r_user_id = $1 AND r_content_id = $2', [parseInt(CURRENT_USER_ID), req.params.id]);
            } else {
                await pool.query(`INSERT INTO rates (r_user_id, r_content_id, score) VALUES ($1, $2, $3) ON CONFLICT (r_user_id, r_content_id) DO UPDATE SET score = EXCLUDED.score`, [parseInt(CURRENT_USER_ID), req.params.id, newScore]);
            }
            res.redirect('/content/' + req.params.id);
        } catch (err) {
            res.status(500).send(err.message);
        }
    });

    // İÇERİK BEĞEN/BEĞENMEİPTAL
    router.post('/content/:id/toggle-like', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const contentId = req.params.id;
            const check = await pool.query("SELECT * FROM content_likes WHERE c_user_id = $1 AND c_content_id = $2", [parseInt(CURRENT_USER_ID), contentId]);
            let isLiked = false;
            if (check.rows.length > 0) {
                await pool.query("DELETE FROM content_likes WHERE c_user_id = $1 AND c_content_id = $2", [parseInt(CURRENT_USER_ID), contentId]);
            } else {
                await pool.query("INSERT INTO content_likes (c_user_id, c_content_id) VALUES ($1, $2)", [parseInt(CURRENT_USER_ID), contentId]);
                isLiked = true;
            }
            const likeCount = await pool.query("SELECT COUNT(*) as count FROM content_likes WHERE c_content_id = $1", [contentId]);
            res.json({ success: true, isLiked, likeCount: parseInt(likeCount.rows[0].count) });
        } catch (err) {
            res.status(500).json({ success: false, error: "Like error." });
        }
    });

    // DISCOVERY (Updated with specific requested queries)
    router.get('/discovery', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const typeFilter = 'Movie';

            // 1. Weekly Trends (Sistemde son 7 gün içinde en çok beğeni alan ilk 10 içerik)
            const weeklyTrendsQuery = `
                SELECT c.*, ct.type_name,
                    (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                    COUNT(cl.c_content_id) as weekly_likes,
                    EXISTS(SELECT 1 FROM content_likes cl2 WHERE cl2.c_content_id = c.content_id AND cl2.c_user_id = $1) as is_liked
                FROM content c
                JOIN content_type ct ON c.c_type_id = ct.type_id
                JOIN content_likes cl ON c.content_id = cl.c_content_id
                WHERE cl.like_date >= CURRENT_DATE - INTERVAL '7 days'
                  AND ct.type_name = $2
                GROUP BY c.content_id, ct.type_name
                ORDER BY weekly_likes DESC, c.avg_score DESC
                LIMIT 10
            `;
            const weeklyTrends = await pool.query(weeklyTrendsQuery, [parseInt(CURRENT_USER_ID) || 0, typeFilter]);

            let recommended = [];
            let basedOnPeople = [];
            let basedOnInterests = [];

            if (CURRENT_USER_ID) {
                // 2. Recommended (Tür Analizi: Son 7 günde hem beğenilen hem de 7+ puan verilen içeriklerin türleri)
                const recQuery = `
                    WITH user_recent_high_rated_likes AS (
                        SELECT DISTINCT bt.b_genre_id
                        FROM belong_to bt
                        JOIN content_likes cl ON bt.b_content_id = cl.c_content_id
                        JOIN rates r ON bt.b_content_id = r.r_content_id
                        WHERE cl.c_user_id = $1 
                          AND r.r_user_id = $1
                          AND cl.like_date >= CURRENT_DATE - INTERVAL '7 days'
                          AND r.score >= 7
                    )
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    JOIN belong_to bt ON c.content_id = bt.b_content_id
                    WHERE bt.b_genre_id IN (SELECT b_genre_id FROM user_recent_high_rated_likes)
                      AND c.avg_score >= 6 AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const recRes = await pool.query(recQuery, [parseInt(CURRENT_USER_ID), typeFilter]);
                recommended = recRes.rows;

                // 3. Author/Director Loyalty (Yönetmen ve Yazar Sadakati Keşfi)
                const peopleQuery = `
                    WITH LoyalPersons AS (
                        SELECT person_id FROM (
                            SELECT m.m_person_id as person_id FROM rates r JOIN movies m ON r.r_content_id = m.m_content_id WHERE r.r_user_id = $1 AND r.score >= 8
                            UNION ALL
                            SELECT s.s_person_id as person_id FROM rates r JOIN series s ON r.r_content_id = s.s_content_id WHERE r.r_user_id = $1 AND r.score >= 8
                            UNION ALL
                            SELECT b.b_person_id as person_id FROM rates r JOIN books b ON r.r_content_id = b.b_content_id WHERE r.r_user_id = $1 AND r.score >= 8
                        ) AS p GROUP BY person_id HAVING COUNT(*) >= 2
                    )
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    LEFT JOIN movies m ON c.content_id = m.m_content_id
                    LEFT JOIN series s ON c.content_id = s.s_content_id
                    LEFT JOIN books b ON c.content_id = b.b_content_id
                    WHERE (m.m_person_id IN (SELECT person_id FROM LoyalPersons) OR s.s_person_id IN (SELECT person_id FROM LoyalPersons) OR b.b_person_id IN (SELECT person_id FROM LoyalPersons))
                      AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const peopleRes = await pool.query(peopleQuery, [parseInt(CURRENT_USER_ID), typeFilter]);
                basedOnPeople = peopleRes.rows;

                // 4. Based on Interests (İlgi Alanına Odaklı İçerik Keşfi)
                const interestQuery = `
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    JOIN belong_to bt ON c.content_id = bt.b_content_id
                    JOIN interest_in ii ON bt.b_genre_id = ii.i_genre_id
                    WHERE ii.i_user_id = $1 AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const interestRes = await pool.query(interestQuery, [parseInt(CURRENT_USER_ID), typeFilter]);
                basedOnInterests = interestRes.rows;
            }

            res.render('discovery', { 
                weeklyTrends: weeklyTrends.rows,
                recommended,
                basedOnPeople,
                basedOnInterests,
                activeMenu: 'discovery',
                isGuest: !CURRENT_USER_ID
            });
        } catch (err) {
            console.error(err);
            res.status(500).send("Discovery error.");
        }
    });

    // API FOR DISCOVERY SECTIONS
    router.get('/api/discovery/section', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const { section, type } = req.query;
        try {
            let contents = [];
            if (section === 'trends') {
                const query = `
                    SELECT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        COUNT(cl.c_content_id) as weekly_likes,
                        EXISTS(SELECT 1 FROM content_likes cl2 WHERE cl2.c_content_id = c.content_id AND cl2.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    JOIN content_likes cl ON c.content_id = cl.c_content_id
                    WHERE cl.like_date >= CURRENT_DATE - INTERVAL '7 days'
                      AND ct.type_name = $2
                    GROUP BY c.content_id, ct.type_name
                    ORDER BY weekly_likes DESC, c.avg_score DESC
                    LIMIT 10
                `;
                const result = await pool.query(query, [parseInt(CURRENT_USER_ID) || 0, type]);
                contents = result.rows;
            } else if (section === 'recommended' && CURRENT_USER_ID) {
                const query = `
                    WITH user_recent_high_rated_likes AS (
                        SELECT DISTINCT bt.b_genre_id
                        FROM belong_to bt
                        JOIN content_likes cl ON bt.b_content_id = cl.c_content_id
                        JOIN rates r ON bt.b_content_id = r.r_content_id
                        WHERE cl.c_user_id = $1 
                          AND r.r_user_id = $1
                          AND cl.like_date >= CURRENT_DATE - INTERVAL '7 days'
                          AND r.score >= 7
                    )
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    JOIN belong_to bt ON c.content_id = bt.b_content_id
                    WHERE bt.b_genre_id IN (SELECT b_genre_id FROM user_recent_high_rated_likes)
                      AND c.avg_score >= 6 AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const result = await pool.query(query, [parseInt(CURRENT_USER_ID), type]);
                contents = result.rows;
            } else if (section === 'people' && CURRENT_USER_ID) {
                const query = `
                    WITH favorite_creators AS (
                        SELECT creator_id FROM (
                            SELECT m.m_person_id as creator_id FROM movies m JOIN rates r ON m.m_content_id = r.r_content_id WHERE r.r_user_id = $1 AND r.score >= 7
                            UNION ALL
                            SELECT s.s_person_id as creator_id FROM series s JOIN rates r ON s.s_content_id = r.r_content_id WHERE r.r_user_id = $1 AND r.score >= 7
                            UNION ALL
                            SELECT b.b_person_id as creator_id FROM books b JOIN rates r ON b.b_content_id = r.r_content_id WHERE r.r_user_id = $1 AND r.score >= 7
                        ) as ratings
                        GROUP BY creator_id
                        HAVING COUNT(*) >= 2
                    )
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    LEFT JOIN movies m ON c.content_id = m.m_content_id
                    LEFT JOIN series s ON c.content_id = s.s_content_id
                    LEFT JOIN books b ON c.content_id = b.b_content_id
                    WHERE (m.m_person_id IN (SELECT creator_id FROM favorite_creators)
                       OR s.s_person_id IN (SELECT creator_id FROM favorite_creators)
                       OR b.b_person_id IN (SELECT creator_id FROM favorite_creators))
                      AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const result = await pool.query(query, [parseInt(CURRENT_USER_ID), type]);
                contents = result.rows;
            } else if (section === 'interests' && CURRENT_USER_ID) {
                const query = `
                    SELECT DISTINCT c.*, ct.type_name,
                        (SELECT string_agg(g.genre_name, ', ') FROM belong_to bt JOIN genre g ON bt.b_genre_id = g.genre_id WHERE bt.b_content_id = c.content_id) as genres,
                        EXISTS(SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1) as is_liked
                    FROM content c
                    JOIN content_type ct ON c.c_type_id = ct.type_id
                    JOIN belong_to bt ON c.content_id = bt.b_content_id
                    JOIN interest_in ii ON bt.b_genre_id = ii.i_genre_id
                    WHERE ii.i_user_id = $1 AND ct.type_name = $2
                      AND NOT EXISTS (SELECT 1 FROM rates r WHERE r.r_content_id = c.content_id AND r.r_user_id = $1)
                      AND NOT EXISTS (SELECT 1 FROM content_likes cl WHERE cl.c_content_id = c.content_id AND cl.c_user_id = $1)
                    ORDER BY c.avg_score DESC LIMIT 10
                `;
                const result = await pool.query(query, [parseInt(CURRENT_USER_ID), type]);
                contents = result.rows;
            }
            res.json({ contents });
        } catch (err) {
            res.status(500).json({ error: "API error." });
        }
    });

    return router;
};
