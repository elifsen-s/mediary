const express = require('express');
const router = express.Router();
const { pool } = require('../db/pool');
const { getUser } = require('../helpers');

// requireAuth middleware (local, state'i app.js'ten alır)
function requireAuth(getCurrentUserId) {
    return (req, res, next) => {
        if (!getCurrentUserId()) {
            if (req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'))) {
                return res.status(401).json({ success: false, error: 'Not authenticated' });
            }
            return res.redirect('/?auth=login');
        }
        next();
    };
}

module.exports = function(getCurrentUserId) {
    const auth = requireAuth(getCurrentUserId);

    // ANA SAYFA
    router.get('/', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const tab = req.query.tab || 'following';
        try {
            let posts = [];
            if (!CURRENT_USER_ID) {
                // If guest, only show popular posts from last 7 days
                const query = `
                    SELECT 
                        p.post_id, p.post_text, p.post_date, 'post' as activity_type,
                        u.user_id, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name,
                        u.pp_url, c.title as content_title, c.content_id, c.poster_url as content_poster,
                        (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count,
                        FALSE as is_liked
                    FROM post p 
                    JOIN users u ON p.p_user_id = u.user_id 
                    LEFT JOIN content c ON p.p_content_id = c.content_id 
                    WHERE p.post_date > NOW() - INTERVAL '1 week'
                    ORDER BY like_count DESC LIMIT 15
                `;
                const result = await pool.query(query);
                posts = result.rows;
                return res.render('index', { posts, isGuest: true, tab: 'popular', activeMenu: 'home' });
            }

            if (tab === 'following') {
                const followingRes = await pool.query('SELECT followed_id FROM follows WHERE followers_id = $1', [parseInt(CURRENT_USER_ID)]);
                const followingIds = followingRes.rows.map(r => r.followed_id);

                const feedQuery = `
                    SELECT p.post_id, p.post_text, p.post_date, 'post' as activity_type, u.user_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.content_id, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $2) as is_liked
                    FROM post p JOIN users u ON p.p_user_id = u.user_id LEFT JOIN content c ON p.p_content_id = c.content_id
                    WHERE p.p_user_id = ANY($1::int[]) OR p.p_user_id = $2
                    ORDER BY p.post_date DESC LIMIT 10
                `;
                const feedResult = await pool.query(feedQuery, [followingIds, parseInt(CURRENT_USER_ID)]);
                posts = feedResult.rows;
            } else {
                // Personalize Popular based on user interests (genres) and last 7 days
                const popularQuery = `
                    SELECT p.post_id, p.post_text, p.post_date, 'post' as activity_type, u.user_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.content_id, c.poster_url as content_poster, 
                           (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, 
                           EXISTS(SELECT 1 FROM post_likes pl3 WHERE pl3.p_post_id = p.post_id AND pl3.p_user_id = $1) as is_liked
                    FROM post p 
                    JOIN users u ON p.p_user_id = u.user_id 
                    LEFT JOIN content c ON p.p_content_id = c.content_id
                    JOIN belong_to bt ON c.content_id = bt.b_content_id
                    JOIN interest_in ii ON bt.b_genre_id = ii.i_genre_id
                    WHERE ii.i_user_id = $1
                      AND p.post_date >= CURRENT_DATE - INTERVAL '7 days'
                    GROUP BY p.post_id, u.user_id, c.content_id
                    ORDER BY like_count DESC
                    LIMIT 10
                `;
                const popularResult = await pool.query(popularQuery, [parseInt(CURRENT_USER_ID)]);
                posts = popularResult.rows;
            }

            res.render('index', { posts, tab, isGuest: false, activeMenu: 'home' });
        } catch (err) {
            console.error(err);
            res.status(500).send("Home page error.");
        }
    });

    // LOAD MORE FOR FEED
    router.get('/api/feed', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const tab = req.query.tab || 'following';
        const offset = parseInt(req.query.offset) || 0;
        try {
            let posts = [];
            if (!CURRENT_USER_ID) {
                const query = `
                    SELECT 
                        p.post_id, p.post_text, p.post_date, 'post' as activity_type,
                        u.user_id, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name,
                        u.pp_url, c.title as content_title, c.content_id, c.poster_url as content_poster,
                        (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count,
                        FALSE as is_liked
                    FROM post p 
                    JOIN users u ON p.p_user_id = u.user_id 
                    LEFT JOIN content c ON p.p_content_id = c.content_id 
                    ORDER BY like_count DESC LIMIT 10 OFFSET $1
                `;
                const result = await pool.query(query, [offset]);
                posts = result.rows;
            } else if (tab === 'following') {
                const followingRes = await pool.query('SELECT followed_id FROM follows WHERE followers_id = $1', [parseInt(CURRENT_USER_ID)]);
                const followingIds = followingRes.rows.map(r => r.followed_id);

                const feedQuery = `
                    SELECT p.post_id, p.post_text, p.post_date, 'post' as activity_type, u.user_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.content_id, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $2) as is_liked
                    FROM post p JOIN users u ON p.p_user_id = u.user_id LEFT JOIN content c ON p.p_content_id = c.content_id
                    WHERE p.p_user_id = ANY($1::int[]) OR p.p_user_id = $2
                    ORDER BY p.post_date DESC LIMIT 10 OFFSET $3
                `;
                const feedResult = await pool.query(feedQuery, [followingIds, parseInt(CURRENT_USER_ID), offset]);
                posts = feedResult.rows;
            } else {
                const popularQuery = `
                    SELECT p.post_id, p.post_text, p.post_date, 'post' as activity_type, u.user_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.content_id, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $1) as is_liked
                    FROM post p JOIN users u ON p.p_user_id = u.user_id LEFT JOIN content c ON p.p_content_id = c.content_id
                    ORDER BY like_count DESC, p.post_date DESC LIMIT 10 OFFSET $2
                `;
                const popularResult = await pool.query(popularQuery, [parseInt(CURRENT_USER_ID), offset]);
                posts = popularResult.rows;
            }
            res.json({ posts });
        } catch (err) {
            res.status(500).json({ error: "Feed error." });
        }
    });

    // SEARCH
    router.get('/search', async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const axios = require('axios');
        const TMDB_API_KEY = process.env.TMDB_API_KEY;
        let { q, type, page, ajax } = req.query;
        if (!type) type = 'Movie';
        let currentPage = parseInt(page) || 1;
        try {
            let results = [];
            let rawApiCount = 0;
            if (q && q.trim() !== '') {
                if (currentPage === 1) {
                    const localResults = await pool.query("SELECT c.*, ct.type_name, TRUE as is_local FROM content c JOIN content_type ct ON c.c_type_id = ct.type_id WHERE c.title ILIKE $1 AND ct.type_name = $2", [`%${q.trim()}%`, type]);
                    results = localResults.rows;
                }
                if (type === 'Movie') {
                    const tmdbRes = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(q)}&language=en-US&page=${currentPage}`);
                    const apiItems = tmdbRes.data.results.map(m => ({ content_id: 'tmdb_' + m.id, title: m.title, release_year: m.release_date?.substring(0,4), poster_url: m.poster_path ? 'https://image.tmdb.org/t/p/w500' + m.poster_path : null, type_name: 'Movie', is_local: false }));
                    rawApiCount = apiItems.length;
                    results = [...results, ...apiItems];
                } else if (type === 'Series') {
                    const tmdbRes = await axios.get(`https://api.themoviedb.org/3/search/tv?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(q)}&language=en-US&page=${currentPage}`);
                    const apiItems = tmdbRes.data.results.map(s => ({ content_id: 'tmdb_tv_' + s.id, title: s.name, release_year: s.first_air_date?.substring(0,4), poster_url: s.poster_path ? 'https://image.tmdb.org/t/p/w500' + s.poster_path : null, type_name: 'Series', is_local: false }));
                    rawApiCount = apiItems.length;
                    results = [...results, ...apiItems];
                } else if (type === 'Book') {
                    const olRes = await axios.get(`https://openlibrary.org/search.json?q=${encodeURIComponent(q)}&limit=20&page=${currentPage}`);
                    const apiItems = olRes.data.docs.map(b => ({ content_id: 'ol_' + (b.key ? b.key.replace('/works/', '') : b.cover_edition_key), title: b.title, release_year: b.first_publish_year || '?', poster_url: b.cover_i ? `https://covers.openlibrary.org/b/id/${b.cover_i}-M.jpg` : null, type_name: 'Book', is_local: false }));
                    rawApiCount = apiItems.length;
                    results = [...results, ...apiItems];
                }
            }
            const seen = new Set();
            results = results.filter(el => { const key = `${el.title.toLowerCase()}-${el.type_name}`; if (seen.has(key)) return false; seen.add(key); return true; });
            results.sort((a, b) => (parseInt(b.release_year) || 0) - (parseInt(a.release_year) || 0));
            const hasMore = rawApiCount >= 20;
            if (ajax) return res.json({ results, hasMore });
            res.render('search', { results, query: q || '', type, currentPage, hasMore, activeMenu: 'search', isGuest: !CURRENT_USER_ID });
        } catch (err) {
            res.status(500).send("Search error.");
        }
    });

    // SEARCH USERS
    router.get('/search-users', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const q = req.query.q || '';
            const searchQuery = `%${q}%`;
            const result = await pool.query(`SELECT user_id, user_name as username, first_name || ' ' || last_name as full_name, pp_url FROM users WHERE (user_name ILIKE $1 OR (first_name || ' ' || last_name) ILIKE $1) AND user_id != $2 LIMIT 20`, [searchQuery, parseInt(CURRENT_USER_ID)]);
            res.render('search-users', { users: result.rows, query: q, activeMenu: 'search' });
        } catch (err) {
            res.status(500).send("Search error.");
        }
    });

    return router;
};
