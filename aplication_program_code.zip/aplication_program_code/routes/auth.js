const express = require('express');
const router = express.Router();
const { pool } = require('../db/pool');

module.exports = function(getState, setState) {
    // LOGIN
    router.post('/login', async (req, res) => {
        const result = await pool.query('SELECT * FROM users WHERE user_name = $1 AND password = $2', [req.body.user_name, req.body.password]);
        if (result.rows.length > 0) {
            setState(result.rows[0].user_id);
            res.redirect('/');
        } else {
            res.redirect('/?auth=login&error=1');
        }
    });

    router.get('/login', (req, res) => res.redirect('/?auth=login'));

    // REGISTER
    router.get('/register', (req, res) => res.render('register', { error: null }));
    router.post('/register', async (req, res) => {
        const { first_name, last_name, user_name, email, password } = req.body;
        const pp_url = `https://ui-avatars.com/api/?name=${encodeURIComponent(first_name + ' ' + last_name)}&background=E60023&color=fff`;
        await pool.query('INSERT INTO users (first_name, last_name, user_name, email, password, pp_url) VALUES ($1, $2, $3, $4, $5, $6)', [first_name, last_name, user_name, email, password, pp_url]);
        res.redirect('/?auth=login');
    });

    // LOGOUT
    router.get('/logout', (req, res) => {
        setState(null);
        res.redirect('/');
    });

    return router;
};
