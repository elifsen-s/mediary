const express = require('express');
const router = express.Router();
const { pool } = require('../db/pool');
const { getUser } = require('../helpers');

function requireAuth(getCurrentUserId) {
    return (req, res, next) => {
        if (!getCurrentUserId()) {
            if (req.xhr || (req.headers.accept && req.headers.accept.includes('application/json'))) {
                return res.status(401).json({ success: false, error: 'Not authenticated' });
            }
            return res.redirect('/?auth=login');
        }
        next();
    };
}

module.exports = function(getCurrentUserId) {
    const auth = requireAuth(getCurrentUserId);

    async function getProfileStats(userId) {
        const posts = await pool.query('SELECT COUNT(*) FROM post WHERE p_user_id = $1', [userId]);
        const followers = await pool.query('SELECT COUNT(*) FROM follows WHERE followed_id = $1', [userId]);
        const following = await pool.query('SELECT COUNT(*) FROM follows WHERE followers_id = $1', [userId]);
        return {
            postCount: parseInt(posts.rows[0].count),
            followersCount: parseInt(followers.rows[0].count),
            followingCount: parseInt(following.rows[0].count)
        };
    }

    // LIKE / UNLIKE POST
    router.post('/post/:id/toggle-like', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const postId = req.params.id;
            const check = await pool.query("SELECT * FROM post_likes WHERE p_user_id = $1 AND p_post_id = $2", [parseInt(CURRENT_USER_ID), postId]);
            let isLiked = false;
            if (check.rows.length > 0) {
                await pool.query("DELETE FROM post_likes WHERE p_user_id = $1 AND p_post_id = $2", [parseInt(CURRENT_USER_ID), postId]);
            } else {
                await pool.query("INSERT INTO post_likes (p_user_id, p_post_id) VALUES ($1, $2)", [parseInt(CURRENT_USER_ID), postId]);
                isLiked = true;
            }
            const likeCount = await pool.query("SELECT COUNT(*) as count FROM post_likes WHERE p_post_id = $1", [postId]);
            res.json({ success: true, isLiked, likeCount: parseInt(likeCount.rows[0].count) });
        } catch (err) {
            res.status(500).json({ success: false, error: "Like error." });
        }
    });

    // DELETE POST
    router.post('/post/:id/delete', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            await pool.query("DELETE FROM post WHERE post_id = $1 AND p_user_id = $2", [req.params.id, parseInt(CURRENT_USER_ID)]);
            res.redirect(req.get('Referrer') || '/');
        } catch (err) {
            res.status(500).send("Delete error.");
        }
    });

    // CREATE POST
    router.get('/create-post', auth, async (req, res) => {
        const allContent = await pool.query('SELECT c.content_id as id, c.title, ct.type_name FROM content c JOIN content_type ct ON c.c_type_id = ct.type_id ORDER BY c.title');
        res.render('create-post', { selectedContent: null, allContent: allContent.rows, activeMenu: 'create', error: req.query.error });
    });

    router.post('/create-post', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const { content_id, post_text } = req.body;
        await pool.query('INSERT INTO post (p_user_id, p_content_id, post_text, post_date) VALUES ($1, $2, $3, NOW())', [parseInt(CURRENT_USER_ID), content_id, post_text]);
        res.redirect('/content/' + content_id);
    });

    // PROFILE
    router.get('/profile', auth, (req, res) => res.redirect('/profile/posts'));

    router.get('/profile/posts', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const user = await getUser(CURRENT_USER_ID);
        const posts = await pool.query('SELECT p.*, p.p_content_id, c.title as content_title, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $1) as is_liked FROM post p LEFT JOIN content c ON p.p_content_id = c.content_id WHERE p.p_user_id = $1 ORDER BY p.post_date DESC', [parseInt(CURRENT_USER_ID)]);
        const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
        res.render('profile-posts', { user, posts: posts.rows, ...stats, isFollowing: false, activeTab: 'posts', activeMenu: 'profile', isOtherUser: false });
    });

    // Liked Routes
    router.get('/profile/liked', auth, (req, res) => res.redirect('/profile/liked-contents'));

    router.get('/profile/liked-contents', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const user = await getUser(CURRENT_USER_ID);
        const likedContents = await pool.query('SELECT c.*, ct.type_name, TRUE as is_liked FROM content_likes cl JOIN content c ON cl.c_content_id = c.content_id JOIN content_type ct ON c.c_type_id = ct.type_id WHERE cl.c_user_id = $1', [parseInt(CURRENT_USER_ID)]);
        const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
        
        res.render('profile', { user, likedContents: likedContents.rows, ...stats, activeTab: 'liked', activeSubTab: 'content', activeMenu: 'profile', isOtherUser: false });
    });

    router.get('/profile/liked-posts', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const user = await getUser(CURRENT_USER_ID);
        const likedPosts = await pool.query(`SELECT p.*, p.p_content_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl2 WHERE pl2.p_post_id = p.post_id) as like_count, TRUE as is_liked FROM post_likes pl JOIN post p ON pl.p_post_id = p.post_id JOIN users u ON p.p_user_id = u.user_id LEFT JOIN content c ON p.p_content_id = c.content_id WHERE pl.p_user_id = $1 ORDER BY p.post_date DESC`, [parseInt(CURRENT_USER_ID)]);
        
        const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
        
        res.render('profile-liked-posts', { user, posts: likedPosts.rows, ...stats, activeTab: 'liked', activeSubTab: 'post', activeMenu: 'profile', isOtherUser: false });
    });

    // Rated Route
    router.get('/profile/rated', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const user = await getUser(CURRENT_USER_ID);
        const ratedContents = await pool.query('SELECT c.*, ct.type_name, r.score as user_score FROM rates r JOIN content c ON r.r_content_id = c.content_id JOIN content_type ct ON c.c_type_id = ct.type_id WHERE r.r_user_id = $1', [parseInt(CURRENT_USER_ID)]);
        const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
        
        res.render('profile-rated', { user, contents: ratedContents.rows, ...stats, activeTab: 'rated', activeMenu: 'profile' });
    });

    router.get('/profile/interests', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const user = await getUser(CURRENT_USER_ID);
            const genres = await pool.query("SELECT * FROM genre ORDER BY genre_name");
            const userInterestIds = (await pool.query("SELECT i_genre_id FROM interest_in WHERE i_user_id = $1", [parseInt(CURRENT_USER_ID)])).rows.map(r => r.i_genre_id);
            const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
            
            res.render('profile-interests', { 
                user, genres: genres.rows, userInterestIds, 
                ...stats,
                activeTab: 'interests', activeMenu: 'profile', isOtherUser: false 
            });
        } catch (err) {
            console.error(err);
            res.status(500).send("Error");
        }
    });

    router.post('/profile/interests', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            await pool.query('DELETE FROM interest_in WHERE i_user_id = $1', [parseInt(CURRENT_USER_ID)]);
            const ids = Array.isArray(req.body.genreIds) ? req.body.genreIds : (req.body.genreIds ? [req.body.genreIds] : []);
            for (const id of ids) {
                await pool.query('INSERT INTO interest_in (i_genre_id, i_user_id) VALUES ($1, $2)', [parseInt(id), parseInt(CURRENT_USER_ID)]);
            }
            res.redirect('/profile/interests');
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    router.get('/profile/following', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const user = await getUser(CURRENT_USER_ID);
            const result = await pool.query(`SELECT u.*, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, TRUE as is_followed_by_me FROM follows f JOIN users u ON f.followed_id = u.user_id WHERE f.followers_id = $1`, [parseInt(CURRENT_USER_ID)]);
            const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
            
            res.render('profile-following', { 
                user, following: result.rows || [], 
                ...stats,
                activeTab: 'following', activeMenu: 'profile', isOtherUser: false, isFollowing: false 
            });
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    router.get('/profile/followers', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const user = await getUser(CURRENT_USER_ID);
            const result = await pool.query(`SELECT u.*, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, EXISTS(SELECT 1 FROM follows WHERE followers_id = $1 AND followed_id = u.user_id) as is_followed_by_me, TRUE as is_follows_me FROM follows f JOIN users u ON f.followers_id = u.user_id WHERE f.followed_id = $1`, [parseInt(CURRENT_USER_ID)]);
            const stats = await getProfileStats(parseInt(CURRENT_USER_ID));
            
            res.render('profile-followers', { 
                user, followers: result.rows || [], 
                ...stats,
                activeTab: 'followers', activeMenu: 'profile', isOtherUser: false, isFollowing: false 
            });
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    // USER PROFILE (other users)
    router.get('/user/:username', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            const { tab } = req.query;
            const userRes = await pool.query("SELECT *, user_name as username, TRIM(CONCAT(first_name, ' ', middle_name, ' ', last_name)) as full_name FROM users WHERE user_name = $1", [req.params.username]);
            const targetUser = userRes.rows[0];
            if (!targetUser) return res.status(404).send("Not found.");
            if (targetUser.user_id === parseInt(CURRENT_USER_ID)) return res.redirect('/profile');

            const isFollowingRes = await pool.query("SELECT * FROM follows WHERE followers_id = $1 AND followed_id = $2", [parseInt(CURRENT_USER_ID), targetUser.user_id]);
            const isFollowing = isFollowingRes.rows.length > 0;

            const stats = await getProfileStats(targetUser.user_id);

            if (tab === 'liked') {
                const sub = req.query.sub || 'content';
                if (sub === 'posts') {
                    const posts = await pool.query(`SELECT p.*, p.p_content_id, u.user_name as username, u.pp_url, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, c.title as content_title, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl2 WHERE pl2.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $2) as is_liked FROM post_likes pl JOIN post p ON pl.p_post_id = p.post_id JOIN users u ON p.p_user_id = u.user_id LEFT JOIN content c ON p.p_content_id = c.content_id WHERE pl.p_user_id = $1 ORDER BY p.post_date DESC`, [targetUser.user_id, parseInt(CURRENT_USER_ID)]);
                    return res.render('profile-liked-posts', { user: targetUser, posts: posts.rows, ...stats, activeTab: 'liked', activeSubTab: 'post', activeMenu: 'profile', isOtherUser: true, isFollowing });
                } else {
                    const contents = await pool.query('SELECT c.*, ct.type_name, EXISTS(SELECT 1 FROM content_likes WHERE c_content_id = c.content_id AND c_user_id = $2) as is_liked FROM content_likes cl JOIN content c ON cl.c_content_id = c.content_id JOIN content_type ct ON c.c_type_id = ct.type_id WHERE cl.c_user_id = $1', [targetUser.user_id, parseInt(CURRENT_USER_ID)]);
                    return res.render('profile', { user: targetUser, likedContents: contents.rows, ...stats, activeTab: 'liked', activeSubTab: 'content', activeMenu: 'profile', isOtherUser: true, isFollowing });
                }
            } else if (tab === 'following') {
                const result = await pool.query(`SELECT u.*, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, EXISTS(SELECT 1 FROM follows WHERE followers_id = $1 AND followed_id = u.user_id) as is_followed_by_me FROM follows f JOIN users u ON f.followed_id = u.user_id WHERE f.followers_id = $2`, [parseInt(CURRENT_USER_ID), targetUser.user_id]);
                return res.render('profile-following', { user: targetUser, following: result.rows || [], ...stats, activeTab: 'following', activeMenu: 'profile', isOtherUser: true, isFollowing });
            } else if (tab === 'followers') {
                const result = await pool.query(`SELECT u.*, u.user_name as username, TRIM(CONCAT(u.first_name, ' ', u.middle_name, ' ', u.last_name)) as full_name, EXISTS(SELECT 1 FROM follows WHERE followers_id = $1 AND followed_id = u.user_id) as is_followed_by_me, EXISTS(SELECT 1 FROM follows WHERE followers_id = u.user_id AND followed_id = $1) as is_follows_me FROM follows f JOIN users u ON f.followers_id = u.user_id WHERE f.followed_id = $2`, [parseInt(CURRENT_USER_ID), targetUser.user_id]);
                return res.render('profile-followers', { user: targetUser, followers: result.rows || [], ...stats, activeTab: 'followers', activeMenu: 'profile', isOtherUser: true, isFollowing });
            } else if (tab === 'interests') {
                const allGenres = await pool.query('SELECT * FROM genre ORDER BY genre_name');
                const userInterests = await pool.query('SELECT i_genre_id FROM interest_in WHERE i_user_id = $1', [targetUser.user_id]);
                return res.render('profile-interests', { user: targetUser, genres: allGenres.rows, userInterestIds: userInterests.rows.map(r => r.i_genre_id), ...stats, activeTab: 'interests', activeMenu: 'profile', isOtherUser: true, isFollowing, readOnly: true });
            }

            const posts = await pool.query('SELECT p.*, p.p_content_id, c.title as content_title, c.poster_url as content_poster, (SELECT COUNT(*) FROM post_likes pl WHERE pl.p_post_id = p.post_id) as like_count, EXISTS(SELECT 1 FROM post_likes WHERE p_post_id = p.post_id AND p_user_id = $1) as is_liked FROM post p LEFT JOIN content c ON p.p_content_id = c.content_id WHERE p.p_user_id = $2 ORDER BY p.post_date DESC', [parseInt(CURRENT_USER_ID), targetUser.user_id]);
            res.render('profile-posts', { user: targetUser, posts: posts.rows, ...stats, isFollowing, isOtherUser: true, activeTab: 'posts', activeMenu: 'profile' });
        } catch (err) {
            console.error(err);
            res.status(500).send("Error");
        }
    });

    // FOLLOW / UNFOLLOW
    router.post('/user/:id/follow', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            await pool.query("INSERT INTO follows (followers_id, followed_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", [parseInt(CURRENT_USER_ID), req.params.id]);
            res.redirect(req.get('Referrer') || '/');
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    router.post('/user/:id/unfollow', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            await pool.query("DELETE FROM follows WHERE followers_id = $1 AND followed_id = $2", [parseInt(CURRENT_USER_ID), req.params.id]);
            res.redirect(req.get('Referrer') || '/');
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    // REMOVE FOLLOWER
    router.post('/user/:id/remove-follower', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            // Remove the follow of :id user on me (CURRENT_USER_ID)
            await pool.query("DELETE FROM follows WHERE followers_id = $1 AND followed_id = $2", [parseInt(req.params.id), parseInt(CURRENT_USER_ID)]);
            res.redirect(req.get('Referrer') || '/profile/followers');
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    // SETTINGS
    router.get('/settings', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        res.render('settings', { user: await getUser(CURRENT_USER_ID), error: null, success: null, activeMenu: 'settings' });
    });

    router.post('/settings', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        const { first_name, last_name, email, password } = req.body;
        if (password) {
            await pool.query('UPDATE users SET first_name = $1, last_name = $2, email = $3, password = $4 WHERE user_id = $5', [first_name, last_name, email, password, parseInt(CURRENT_USER_ID)]);
        } else {
            await pool.query('UPDATE users SET first_name = $1, last_name = $2, email = $3 WHERE user_id = $4', [first_name, last_name, email, parseInt(CURRENT_USER_ID)]);
        }
        res.redirect('/settings?success=1');
    });

    router.post('/settings/update-pp', auth, async (req, res) => {
        const CURRENT_USER_ID = getCurrentUserId();
        try {
            await pool.query('UPDATE users SET pp_url = $1 WHERE user_id = $2', [req.body.pp_url, parseInt(CURRENT_USER_ID)]);
            res.redirect('back');
        } catch (err) {
            res.status(500).send("Error");
        }
    });

    return router;
};
